THINKUP V1 — Prototype app

Included:
- Dark mobile-friendly interface
- Beginner, Intermediate, Advanced and Expert levels
- Three-question starting check
- Logic, Memory, Math, Patterns, Focus and Observation games
- Points, games played, accuracy and day streak
- Local progress saved in this browser/device
- Basic offline caching / PWA files

To test:
Open index.html in a browser. For installation as an app, host this folder on an HTTPS static host (for example GitHub Pages or Netlify), then use the browser's Add to Home Screen / Install option.

Important:
This is a front-end prototype. It has no accounts, cloud sync, payments, or online leaderboard. Progress stays in the browser's local storage and may be lost if site data is cleared. The starting check is a simple warm-up, not a validated cognitive assessment.
